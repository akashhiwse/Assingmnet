package com.YASH.String;


	public class  ObjCompariDemo
	{
	    public static void main(String[] args)
	    {
	        String s1=new String("Yash");
	        String s2=new String("Yash");
	        System.out.println(s1==s2);//false
	        String s3="jaynam";
	        String s4="jaynam";
	        System.out.println(s3==s4);//true
	        System.out.println(s1.equals(s2));//true
	       
	       
	    }
	   
	}

